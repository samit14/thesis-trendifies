const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

module.exports.verifyUser = function (req, res, next) {
  try {
    const data = jwt.verify(token, "anysecretkey");
    User.findOne({ _id: data.uid })
      .then(function (result) {
        console.log(result);
        req.userInfo = result;
        next();
      })
      .catch(function (e) {
        res.status(400).json({ msg: "Invalid token", error: e });
      });
  } catch (e) {
    res.status(400).json({ msg: "Invalid token", error: e });
  }
};

module.exports.verifyAdmin = function (req, res, next) {
  try {
    token = req.body.tok;
    const data = jwt.verify(token, "anysecretkey");
    User.findOne({ _id: data.uid })
      .then(function (result) {
        if (result.isAdmin) {
          req.userInfo = result;
          next();
        } else {
          res.status(400).json({ msg: "User is not an admin" });
        }
      })
      .catch(function (e) {
        res.status(400).json({ msg: "Invalid token", error: e });
      });
  } catch (e) {
    res.status(400).json({ msg: "Invalid token", error: e });
  }
};
