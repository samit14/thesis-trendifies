const Product = require("../models/productModel");
const Order = require("../models/orderModel");
const mongoose = require("mongoose");

const url = "mongodb://localhost:27017/myProjectDB";

beforeAll(async () => {
  await mongoose.connect(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe("Testing product schema", () => {
  //the code below is for insert testing
  it("Add product in db testing", () => {
    const product = {
      name: "Nokia",
      price: 200,
    };
    return Product.create(product).then((pro_ret) => {
      expect(pro_ret.name).toEqual("Nokia");
    });
  });

  //testing if the update is working
  it("Updating the added product testing", async () => {
    const status = await Product.updateOne(
      { name: "Nokia" },
      {
        name: "Apple",
        price: "300",
      }
    );
    expect(status.ok);

    // .then((res) => {
    //   expect(res.name).toEqual("Apple");
    // });
  });
  //the below code is for delete testing

  // delete testing;
  it("Deleting the product testing", async () => {
    const status = await Product.findOneAndDelete({ name: "Apple" });
    expect(status.ok);
  });

  //the below code is for update testing here
});
