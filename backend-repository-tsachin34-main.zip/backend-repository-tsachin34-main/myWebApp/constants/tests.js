const TESTING_HOST = "localhost";
const TESTING_PORT = 3001;
const TESTING_URL = `http://${TESTING_HOST}:${TESTING_PORT}`;

module.exports = {
  TESTING_HOST,
  TESTING_PORT,
  TESTING_URL,
};
