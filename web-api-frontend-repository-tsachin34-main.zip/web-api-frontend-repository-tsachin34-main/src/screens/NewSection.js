import React from "react";
import bg1 from "../style/images/featured/bg1.jpg";
import Rating from "react-rating";
import blackfit from "../style/images/blackfit.jpg"

const colors = {
  orange: "#FFBA5A",
  grey: "#a9a9a9",
};

const handleClick = (mylink) => () => {
  window.location.href = mylink;
};

export const NewSection = () => {
  
  return (
    <div id="new" className="w-100">
      <div className="row p-0 m-0">
        <div className="one col-lg-4 col-md-12 col-sm-12 p-0">
          <img
            className="img-fluid"
            src="https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          ></img>

          <div className="details">
            <h2>Extreme Rare Sneaker</h2>
            <button className="tex-uppercase">Shop now</button>
          </div>
        </div>
        <div className="one col-lg-4 col-md-12 col-sm-12 p-0">
          <img
            className="img-fluid"
            src={blackfit}
          ></img>

          <div className="details">
            <h2>Awesome Black Outfit</h2>
            <button className="tex-uppercase">Shop now</button>
          </div>
        </div>
        <div className="one col-lg-4 col-md-12 col-sm-12 p-0">
          <img
            className="img-fluid"
            src="https://images.pexels.com/photos/7165175/pexels-photo-7165175.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          ></img>

          <div className="details">
            <h2>Sportwear up to 50% off</h2>
            <button className="tex-uppercase">Shop now</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const Featured = () => {
  return (
    <div>
      <div id="featured" className="my-5 pb-5">
        <div className="container text-center mt-5 py-5">
          <h3>Our Featured</h3>
          <hr className="mx-auto  org-hr" />
          <p>
            Here you can check our new products with fair price in Trendyfits.
          </p>
        </div>

        <div className="row mx-auto container-fluid">
          <div
            onClick={handleClick('/sproduct')}
            className="product text-center col-lg-3 col-md-4 col-sm-12"
          >
            <img className="img-fluid mb-3" src="https://eu.louisvuitton.com/images/is/image/lv/1/PP_VP_L/louis-vuitton-precious-tiger-scarf-for-women--M77386_PM2_Front%20view.png?wid=656&hei=656"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://eu.louisvuitton.com/images/is/image/lv/1/PP_VP_L/louis-vuitton-chunky-intarsia-football-t-shirt-ready-to-wear--HMN66WJYB900_PM2_Front%20view.png?wid=656&hei=656"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://eu.louisvuitton.com/images/is/image/lv/1/PP_VP_L/louis-vuitton-tie-dye-t-shirt-with-lv-signature-ready-to-wear--HMY73WNPL50Z_PM2_Front%20view.png?wid=656&hei=656"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://eu.louisvuitton.com/images/is/image/lv/1/PP_VP_L/louis-vuitton-horizon-soft-55-other-monogram-canvas-travel--M20115_PM2_Front%20view.png?wid=656&hei=656"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const Banner = () => {
  return (
    <div id="banner" className="my-5 py-5">
      <div className="container">
        <h4>MID SEASON'S SALE</h4>
        <h1>
         Winter Collection<br /> UP TO 25% OFF
        </h1>
        <button className="text-uppercase">Shop Now</button>
      </div>
    </div>
  );
};

export const BrandNew = () => {
  return (
    <div>
      <div id="featured my-5 py-4">
        <div className="container text-center mt-5 py-5">
          <h3>Brand New</h3>
          <hr className="mx-auto org-hr" />
          <p>
          Products that just landed fresh on the market. Check it out.
          </p>
        </div>

        <div className="row mx-auto container-fluid">
          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://www.goldstarshoes.com/Media/starlite_04_(2).jpg"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://www.goldstarshoes.com/Media/271212202_5067592363260644_7908891534745222614_n.jpg"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://www.goldstarshoes.com/Media/271463519_5070666249619922_1619995335154167526_n.jpg"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>

          <div className="product text-center col-lg-3 col-md-4 col-sm-12">
            <img className="img-fluid mb-3" src="https://www.goldstarshoes.com/Media/l_1004_(2).jpg"></img>
            <div className="star">
              <Rating
                style={{ color: colors.orange }}
                initialRating={5}
                emptySymbol="fa fa-star-o "
                fullSymbol="fa fa-star"
                readonly={true}
              />
            </div>
            <h5 className="p-name">Sports shoes</h5>
            <h4 className="p-price">$400</h4>

            <button className="buy-btn">Buy Now</button>
          </div>
        </div>
      </div>
    </div>
  );
};
