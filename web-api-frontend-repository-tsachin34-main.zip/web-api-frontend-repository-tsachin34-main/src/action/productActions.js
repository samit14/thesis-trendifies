import axios from "axios";

export const getAllProducts = () => (dispatch) => {
  dispatch({ type: "GET_PRODUCTS_REQUEST" });
  axios
    .get("/api/products/getallproducts")
    .then((res) => {
      console.log(res);
      dispatch({ type: "GET_PRODUCTS_SUCCESS", payload: res.data.data });
    })
    .catch((err) => {
      console.log(err);
      dispatch({ type: "GET_PRODUCTS_FAILED", payload: err });
    });
};

export const getProductById = (productid) => (dispatch) => {
  console.log("in here sir");
  axios
    .post("/api/products/getproductbyid", { productid })
    .then((res) => {
      console.log(res);
      dispatch({ type: "GET_PRODUCTBYID_SUCCESS", payload: res.data });
    })
    .catch((err) => {
      console.log(err);
      dispatch({ type: "GET_PRODUCTBYID_FAILED", payload: err });
    });
};

export const filterProducts = (searchkey, sort, category) => (dispatch) => {
  var filteredproducts;
  console.log(sort);
  console.log(category);
  console.log(searchkey);
  dispatch({ type: "GET_PRODUCTS_REQUEST" });

  axios
    .get("/api/products/getallproducts")
    .then((res) => {
      filteredproducts = res.data.data;
      if (searchkey) {
        filteredproducts = res.data.data.filter((product) => {
          return product.name.toLowerCase().includes(searchkey);
        });
        console.log(filteredproducts);
      }
      if (sort !== "popular") {
        if (sort == "htl") {
          filteredproducts = res.data.data.sort((a, b) => {
            return -a.price + b.price;
          });
        } else {
          filteredproducts = res.data.data.sort((a, b) => {
            return a.price - b.price;
          });
        }
      }
      if (category !== "all") {
        filteredproducts = res.data.data.filter((product) => {
          return product.category.toLowerCase().includes(category);
        });
      }

      console.log(filteredproducts);
      dispatch({ type: "GET_PRODUCTS_SUCCESS", payload: filteredproducts });
    })
    .catch((err) => {
      dispatch({ type: "GET_PRODUCTS_FAILED", payload: err });
    });
};

export const addProductReview = (review, productid) => (dispatch, getState) => {
  dispatch({ type: "ADD_PRODUCT_REVIEW_REQUEST" });
  const tok = JSON.parse(localStorage.getItem("currentUserToken"));
  const currentUserData = getState().loginReducer.currentUserData;

  axios
    .post("/api/products/addreview", {
      review,
      productid,
      currentUserData,
      tok,
    })
    .then((res) => {
      console.log(res);
      dispatch({ type: "ADD_PRODUCT_REVIEW_SUCCESS" });
      alert("review submitted");
      window.location.reload();
    })
    .catch((err) => {
      dispatch({ type: "ADD_PRODUCT_REVIEW_FAILED" });
    });
};

export const deleteProduct = (productid) => (dispatch) => {
  dispatch({ type: "DELETE_PRODUCT_REQUEST" });
  const tok = JSON.parse(localStorage.getItem("currentUserToken"));
  axios
    .post("/api/products/deleteproduct", { productid, tok })
    .then((res) => {
      console.log(res);
      dispatch({ type: "DELETE_PRODUCT_SUCCESS", payload: res.data });
      alert("products deleted successfully");
      window.location.reload();
    })
    .catch((err) => {
      dispatch({ type: "DELETE_PRODUCT_FAILED", payload: err });
    });
};

export const addProduct = (product) => (dispatch) => {
  dispatch({ type: "ADD_PRODUCT_REQUEST" });
  axios
    .post("/api/products/addproduct",product )
    .then((res) => {
      console.log(res);
      dispatch({ type: "ADD_PRODUCT_SUCCESS" });
      window.location.reload();
    })
    .catch((err) => {
      dispatch({ type: "ADD_PRODUCT_FAILED" });
    });
};

export const updateProduct = (productid, updatedProduct) => (dispatch) => {
  dispatch({ type: "UPDATE_PRODUCT_REQUEST" });
  const tok = localStorage.getItem("currentUserToken");
  console.log(tok);
  const config = { headers: { Authorization: "Bearer " + tok } };
  console.log(updatedProduct);
  axios
    .post("/api/products/updateProduct", { productid, updatedProduct }, config)
    .then((res) => {
      console.log(res);
      dispatch({ type: "UPDATE_PRODUCT_SUCCESS" });
      window.location.href = "/admin/productslist";
    })
    .catch((err) => {
      dispatch({ type: "UPDATE_PRODUCT_FAILED" });
    });
};
